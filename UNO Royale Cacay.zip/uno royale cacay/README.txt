UNO! CLUB — Game UNO berbasis website

CARA MENJALANKAN
1. Ekstrak file ZIP.
2. Buka folder uno_website.
3. Klik dua kali index.html atau buka dengan Google Chrome.
4. Pilih mode:
   - Lawan komputer
   - Bermain bersama teman (bergantian pada satu perangkat)
5. Masukkan nama, lalu tekan MULAI BERMAIN.

FITUR
- Kartu merah, biru, hijau, kuning, dan Wild.
- Kartu aksi Skip, Reverse, +2, dan +4.
- Mode melawan komputer.
- Mode 2–4 pemain lokal pada satu perangkat.
- Ambil kartu, pilih warna Wild, dan tombol UNO.
- Tampilan responsif untuk desktop dan ponsel.

Catatan: Ini versi permainan lokal satu perangkat. Mode teman belum memakai multiplayer online.
